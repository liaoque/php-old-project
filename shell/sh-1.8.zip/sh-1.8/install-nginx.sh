#!/bin/bash

####---- global variables ----begin####
export nginx_version=1.16.1
export php_version=5.5.38
####---- global variables ----end####


web=nginx
install_log=/alidata/website-info.log


####---- version selection ----begin####

tmp=1
isphp_jdk=0
if echo $web |grep "nginx" > /dev/null;then
  read -p "Please select the nginx version of 1.16.1, input 1: " tmp
  if [ "$tmp" == "1" ];then
    nginx_version=1.16.1
  fi
fi



echo ""
echo "You select the version :"
echo "web    : $web"
if echo $web |grep "nginx" > /dev/null;then
  echo "nginx : $nginx_version"
fi


read -p "Enter the y or Y to continue:" isY
if [ "${isY}" != "y" ] && [ "${isY}" != "Y" ];then
   exit 1
fi
####---- version selection ----end####





if echo $web|grep "nginx" > /dev/null;then
web_dir=nginx-${nginx_version}
fi


if [ `uname -m` == "x86_64" ];then
machine=x86_64
else
machine=i686
fi


####---- global variables ----begin####
export web
export web_dir


####---- global variables ----end####


ifredhat=$(cat /proc/version | grep redhat)
ifcentos=$(cat /proc/version | grep centos)
ifubuntu=$(cat /proc/version | grep ubuntu)
ifdebian=$(cat /proc/version | grep -i debian)
ifgentoo=$(cat /proc/version | grep -i gentoo)
ifsuse=$(cat /proc/version | grep -i suse)
ifAliCloud=$(cat /proc/version | grep AliCloud)


\cp /etc/rc.local /etc/rc.local.bak > /dev/null
if [ "$ifcentos" != "" ];then
#	if grep 5.10 /etc/issue;then
	  rpm --import /etc/pki/rpm-gpg/RPM-GPG-KEY-CentOS-5 &> /dev/null
#	fi
  sed -i 's/^exclude/#exclude/' /etc/yum.conf
  yum makecache
  yum -y install gcc gcc-c++  make cmake libtool autoconf patch unzip automake libxml2 libxml2-devel ncurses ncurses-devel libtool-ltdl-devel libtool-ltdl libmcrypt libmcrypt-devel libpng libpng-devel libjpeg-devel openssl openssl-devel curl curl-devel libxml2 libxml2-devel ncurses ncurses-devel libtool-ltdl-devel libtool-ltdl autoconf automake pcre pcre-devel libaio*
  yum install -y giflib-devel libtiff-devel jasper-devel re2c bison
  yum -y update bash
  iptables -F
fi
####---- install dependencies ----end####

####---- install software ----begin####
rm -f tmp.log
echo tmp.log

./env/install_set_sysctl.sh
./env/install_set_ulimit.sh

#if [ -e /dev/xvdb ] && [ "$ifsuse" == "" ] ;then
#### 注释挂载脚本
	###./env/install_disk.sh
#fi

./env/install_dir.sh
echo "---------- make dir ok ----------" >> tmp.log



if echo $web |grep "nginx" > /dev/null;then
	./nginx/install_nginx+php-${nginx_version}.sh
	echo "---------- ${web_dir} ok ----------" >> tmp.log
fi

####---- install software ----end####

cat /etc/redhat-release |grep 7\..*|grep -i centos>/dev/null
if [ ! $? -ne  0 ] ;then
   systemctl stop firewalld.service 
   systemctl disable firewalld.service
   cp /etc/rc.local /etc/rc.local.bak > /dev/null
   cp /etc/rc.d/rc.local /etc/rc.d/rc.local.bak > /dev/null
   chmod u+x /etc/rc.local
   chmod u+x /etc/rc.d/rc.local
else 
   echo "it is not centos7"
fi

####---- Start command is written to the rc.local ----begin####
if [ "$ifgentoo" != "" ];then

	if echo $web|grep "nginx" > /dev/null;then
	  if ! cat /etc/local.d/sysctl.start | grep "/etc/init.d/nginx" > /dev/null;then 
		 echo "/etc/init.d/nginx start" >> /etc/local.d/sysctl.start
	  fi
	  if [ $isphp_jdk == "1" ];then
		 if ! cat /etc/local.d/sysctl.start |grep "/etc/init.d/php-fpm" > /dev/null;then
			echo "/etc/init.d/php-fpm start" >> /etc/local.d/sysctl.start
		 fi
	  fi
	fi
elif [ "$ifsuse" != "" ];then
	if echo $web|grep "nginx" > /dev/null;then
	  if ! cat /etc/rc.d/boot.local | grep "/etc/init.d/nginx" > /dev/null;then 
		 echo "/etc/init.d/nginx start" >> /etc/rc.d/boot.local
	  fi
	fi
else
    cat /etc/issue |grep 14\..* >/dev/null
    if [ ! $? -ne  0 ] ;then
	    if echo $web|grep "nginx" > /dev/null;then
	      if ! cat /etc/rc.local | grep "/etc/init.d/nginx" > /dev/null;then 
		    echo "/etc/init.d/nginx start" >> /etc/init.d/rc.local
	      fi
	    fi
    else 
        echo "it is not  ubuntu 14"
	    if echo $web|grep "nginx" > /dev/null;then
	      if ! cat /etc/rc.local | grep "/etc/init.d/nginx" > /dev/null;then 
		    echo "/etc/init.d/nginx start" >> /etc/rc.local
	      fi
	    fi
	fi
fi
####---- Start command is written to the rc.local ----end####


####---- centos yum configuration----begin####
if [ "$ifcentos" != "" ] && [ "$machine" == "x86_64" ];then
sed -i 's/^#exclude/exclude/' /etc/yum.conf
fi
if [ "$ifubuntu" != "" ] || [ "$ifdebian" != "" ];then
	mkdir -p /var/lock
	sed -i 's#exit 0#touch /var/lock/local#' /etc/rc.local
else
	mkdir -p /var/lock/subsys/
fi
####---- centos yum configuration ----end####


####---- Environment variable settings ----begin####
if [ "$ifsuse" != "" ];then
	\cp /etc/profile.d/profile.sh /etc/profile.d/profile.sh.bak
	if echo $web|grep "nginx" > /dev/null;then
	  if [ $isphp_jdk == "1" ];then
		echo 'export PATH=$PATH:/alidata/server/nginx/sbin' >> /etc/profile.d/profile.sh
		export PATH=$PATH:/alidata/server/nginx/sbin
	  fi
	fi
else
	\cp /etc/profile /etc/profile.bak
	if echo $web|grep "nginx" > /dev/null;then
	  if [ $isphp_jdk == "1" ];then
		echo 'export PATH=$PATH:/alidata/server/nginx/sbin' >> /etc/profile
		export PATH=$PATH:/alidata/server/nginx/sbin
	  fi
	fi
fi
####---- Environment variable settings ----end####


####---- restart ----begin####
/etc/init.d/nginx restart &> /dev/null


#/etc/init.d/tomcat7 restart &> /dev/null
####---- restart ----end####

####---- openssl update---begin####
####./env/update_openssl.sh
####---- openssl update---end####

####---- log ----begin####
\cp tmp.log $install_log
cat $install_log
bash
source /etc/profile &> /dev/null
source /etc/profile.d/profile.sh &> /dev/null
bash
####---- log ----end####