#!/bin/bash


# groupmod -g 1010 www && usermod -u 1010 www




# mkdir /alidata/server/rsync/client /alidata/server/rsync/server -p
# cp ./res/rsyncd.conf /alidata/server/rsync/client/rsyncd.conf
# cp ./res/rsyncd.rsync.pas /alidata/server/rsync/client/rsyncd.rsync.pas
# chmod 600 /alidata/server/rsync/client/rsyncd.rsync.pas

# echo "rsync --daemon --config=/alidata/server/rsync/cleint/rsyncd.conf"  >> /etc/rc.local

# tmprsync=1
# read -p "Please rsync server ip : " tmprsync
# sed -i 's/^hosts allow=172.17.0.13/hosts allow='${tmprsync}'/' /alidata/server/rsync/client/rsyncd.conf


# cp ./res/sersync2 /alidata/server/rsync/server/sersync2
# cp ./res/confxml.xml /alidata/server/rsync/server/confxml.xml
# cp ./res/serrsync.pas /alidata/server/rsync/server/serrsync.pas
# chmod 600 /alidata/server/rsync/server/serrsync.pas
# chmod +x /alidata/server/rsync/server/sersync2

##echo "/alidata/server/rsync/server/sersync2 -d -r -n 10 -o /alidata/server/rsync/server/confxml.xml"  >> /etc/rc.local

 
