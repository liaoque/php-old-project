#!/bin/bash
ifsuse=$(cat /proc/version | grep -i suse)

if [ `uname -m` == "x86_64" ];then
machine=x86_64
else
machine=i686
fi

#igbinary
if [ ! -f igbinary-2.0.8.tgz ];then
	wget http://img.okwan.com/pack/igbinary-2.0.8.tgz
fi
rm -rf igbinary-2.0.8
tar -xzvf igbinary-2.0.8.tgz
cd igbinary-2.0.8
/alidata/server/php/bin/phpize
./configure  --with-php-config=/alidata/server/php/bin/php-config
CPU_NUM=$(cat /proc/cpuinfo | grep processor | wc -l)
if [ $CPU_NUM -gt 1 ];then
    make -j$CPU_NUM
else
    make
fi
make install
cd ..
echo "extension=igbinary.so" >> /alidata/server/php/etc/php.ini

#redis
if [ ! -f phpredis-4.1.1.tgz ];then
	wget http://img.okwan.com/pack/phpredis-4.1.1.tar.gz
fi
rm -rf phpredis-4.1.1
tar -xzvf phpredis-4.1.1.tar.gz
cd phpredis-4.1.1
/alidata/server/php/bin/phpize
./configure --enable-redis-igbinary --with-php-config=/alidata/server/php/bin/php-config
CPU_NUM=$(cat /proc/cpuinfo | grep processor | wc -l)
if [ $CPU_NUM -gt 1 ];then
    make -j$CPU_NUM
else
    make
fi
make install
cd ..
echo "extension=redis.so" >> /alidata/server/php/etc/php.ini



#zend
if ls -l /alidata/server/ |grep "5.5.7" > /dev/null;then
  mkdir -p /alidata/server/php/lib/php/extensions/no-debug-non-zts-20121212/
  if [ $machine == "x86_64" ];then
	wget http://zy-res.oss-cn-hangzhou.aliyuncs.com/php/zend/zend-loader-php5.5-linux-x86_64.tar.gz
	tar zxvf zend-loader-php5.5-linux-x86_64.tar.gz
	mv ./zend-loader-php5.5-linux-x86_64/ZendGuardLoader.so /alidata/server/php/lib/php/extensions/no-debug-non-zts-20121212/
  else
    wget http://zy-res.oss-cn-hangzhou.aliyuncs.com/php/zend/zend-loader-php5.5-linux-i386.tar.gz
    tar zxvf zend-loader-php5.5-linux-i386.tar.gz
    mv ./zend-loader-php5.5-linux-i386/ZendGuardLoader.so /alidata/server/php/lib/php/extensions/no-debug-non-zts-20121212/
  fi
    echo "zend_extension=/alidata/server/php/lib/php/extensions/no-debug-non-zts-20121212/ZendGuardLoader.so" >> /alidata/server/php/etc/php.ini
    echo "zend_loader.enable=1" >> /alidata/server/php/etc/php.ini
    echo "zend_loader.disable_licensing=0" >> /alidata/server/php/etc/php.ini
    echo "zend_loader.obfuscation_level_support=3" >> /alidata/server/php/etc/php.ini
    echo "zend_loader.license_path=" >> /alidata/server/php/etc/php.ini
else
  #gmagick
  if [ ! -f gmagick-2.0.5RC1.tgz ];then
  	wget http://img.okwan.com/pack/gmagick-2.0.5RC1.tgz
  fi
  rm -rf gmagick-2.0.5RC1
  tar -xzvf gmagick-2.0.5RC1.tgz
  cd gmagick-2.0.5RC1
  /alidata/server/php/bin/phpize
   ./configure --with-php-config=/alidata/server/php/bin/php-config
  CPU_NUM=$(cat /proc/cpuinfo | grep processor | wc -l)
  if [ $CPU_NUM -gt 1 ];then
      make -j$CPU_NUM
  else
      make
  fi
  make install
  cd ..
  echo "extension=gmagick.so" >> /alidata/server/php/etc/php.ini
fi