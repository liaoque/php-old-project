#!/bin/sh
CPU_NUM=$(cat /proc/cpuinfo | grep processor | wc -l)
if [ ! -f libiconv-1.15.tar.gz ];then
	wget http://img.okwan.com/pack/re2c-1.1.1.tar.gz
fi
rm -rf re2c-1.1.1
tar zxvf re2c-1.1.1.tar.gz
cd re2c-1.1.1
./configure --prefix=/usr/local
if [ $CPU_NUM -gt 1 ];then
    make -j$CPU_NUM
else
    make
fi
make install
cd ..


if [ ! -f libiconv-1.15.tar.gz ];then
	wget http://img.okwan.com/pack/libiconv-1.15.tar.gz
fi
rm -rf libiconv-1.15
tar zxvf libiconv-1.15.tar.gz
cd libiconv-1.15
./configure --prefix=/usr/local
if [ $CPU_NUM -gt 1 ];then
    make -j$CPU_NUM
else
    make
fi
make install
cd ..

if [ ! -f zlib-1.2.5.tar.gz ];then
	wget http://img.okwan.com/pack/zlib-1.2.5.tar.gz
fi
rm -rf zlib-1.2.5
tar zxvf zlib-1.2.5.tar.gz
cd zlib-1.2.5
./configure
if [ $CPU_NUM -gt 1 ];then
    make CFLAGS=-fpic -j$CPU_NUM
else
    make CFLAGS=-fpic
fi
make install
cd ..

if [ ! -f freetype-2.4.0.tar.gz ];then
	wget http://img.okwan.com/pack/freetype-2.4.0.tar.gz
fi
rm -rf freetype-2.4.0
tar zxvf freetype-2.4.0.tar.gz
cd freetype-2.4.0
./configure --prefix=/usr/local/freetype.2.4.0
if [ $CPU_NUM -gt 1 ];then
    make -j$CPU_NUM
else
    make
fi
make install
yum install -y freetype-devel
cd ..

if [ ! -f libpng-1.2.50.tar.gz ];then
	#wget http://soft.phpwind.me/web/libpng-1.2.8.tar.gz
    wget http://oss.aliyuncs.com/aliyunecs/onekey/libpng-1.2.50.tar.gz
fi
rm -rf libpng-1.2.50
tar zxvf libpng-1.2.50.tar.gz
cd libpng-1.2.50
./configure --prefix=/usr/local/libpng.1.2.50
if [ $CPU_NUM -gt 1 ];then
    make CFLAGS=-fpic -j$CPU_NUM
else
    make CFLAGS=-fpic
fi
make install
cd ..

if [ ! -f libevent-2.1.8.tar.gz ];then
	wget http://img.okwan.com/pack/libevent-2.1.8.tar.gz
fi
rm -rf libevent-2.1.8-stable
tar zxvf libevent-2.1.8.tar.gz
cd libevent-2.1.8-stable
./configure
if [ $CPU_NUM -gt 1 ];then
    make -j$CPU_NUM
else
    make
fi
make install
cd ..


if [ ! -f libzip-1.2.0.tar.gz ];then
	wget http://img.okwan.com/pack/libzip-1.2.0.tar.gz
fi
yum remove libzip* -y
rm -rf libzip-1.2.0
tar zxvf libzip-1.2.0.tar.gz
cd libzip-1.2.0
./configure
if [ $CPU_NUM -gt 1 ];then
    make -j$CPU_NUM
else
    make
fi
make install
cp /usr/local/lib/libzip/include/zipconf.h /usr/local/include/zipconf.h
cd ..

#####################################################################################
#if [ ! -f libmcrypt-2.5.8.tar.gz ];then
#	wget http://img.okwan.com/pack/libmcrypt-2.5.8.tar.gz
#fi
#rm -rf libmcrypt-2.5.8
#tar zxvf libmcrypt-2.5.8.tar.gz
#cd libmcrypt-2.5.8
#./configure --disable-posix-threads
#if [ $CPU_NUM -gt 1 ];then
#    make -j$CPU_NUM
#else
#    make
#fi
#make install
#/sbin/ldconfig
#cd libltdl/
#./configure --enable-ltdl-install
#make
#make install
#cd ../..
#####################################################################################


if [ ! -f pcre-8.42.tar.gz ];then
	wget http://img.okwan.com/pack/pcre-8.42.tar.gz
fi
rm -rf pcre-8.42
tar zxvf pcre-8.42.tar.gz
cd pcre-8.42
./configure
if [ $CPU_NUM -gt 1 ];then
    make -j$CPU_NUM
else
    make
fi
make install
cd ..

if [ ! -f GraphicsMagick-1.3.30.tar.gz ];then
	wget http://img.okwan.com/pack/GraphicsMagick-1.3.30.tar.gz
fi
rm -rf GraphicsMagick-1.3.30
tar zxvf GraphicsMagick-1.3.30.tar.gz
cd GraphicsMagick-1.3.30
./configure --with-ttf=/usr/local/freetype.2.4.0 --enable-shared
if [ $CPU_NUM -gt 1 ];then
    make -j$CPU_NUM
else
    make
fi
make install
cd ..

if [ ! -f jpegsrc.v6b.tar.gz ];then
	wget http://oss.aliyuncs.com/aliyunecs/onekey/jpegsrc.v6b.tar.gz
fi
rm -rf jpeg-6b
tar zxvf jpegsrc.v6b.tar.gz
cd jpeg-6b
if [ -e /usr/share/libtool/config.guess ];then
cp -f /usr/share/libtool/config.guess .
elif [ -e /usr/share/libtool/config/config.guess ];then
cp -f /usr/share/libtool/config/config.guess .
fi
if [ -e /usr/share/libtool/config.sub ];then
cp -f /usr/share/libtool/config.sub .
elif [ -e /usr/share/libtool/config/config.sub ];then
cp -f /usr/share/libtool/config/config.sub .
fi
./configure --prefix=/usr/local/jpeg.6 --enable-shared --enable-static
mkdir -p /usr/local/jpeg.6/include
mkdir -p /usr/local/jpeg.6/lib
mkdir -p /usr/local/jpeg.6/bin
mkdir -p /usr/local/jpeg.6/man/man1
if [ $CPU_NUM -gt 1 ];then
    make -j$CPU_NUM
else
    make
fi
make install-lib
make install
cd ..

if [ ! -f yasm-1.3.0.tar.gz ];then
	wget http://img.okwan.com/pack/yasm-1.3.0.tar.gz
fi
rm -rf yasm-1.3.0
tar zxvf yasm-1.3.0.tar.gz
cd yasm-1.3.0
./configure
if [ $CPU_NUM -gt 1 ];then
    make -j$CPU_NUM
else
    make
fi
make install
cd ..

if [ ! -f ffmpeg-4.0.tar ];then
	wget http://img.okwan.com/pack/ffmpeg-4.0.tar
fi
rm -rf ffmpeg-4.0
tar xf ffmpeg-4.0.tar
cd ffmpeg-4.0
./configure
if [ $CPU_NUM -gt 1 ];then
    make -j$CPU_NUM
else
    make
fi
make install
cd ..

#load /usr/local/lib .so
touch /etc/ld.so.conf.d/usrlib.conf
echo "/usr/local/lib" > /etc/ld.so.conf.d/usrlib.conf
/sbin/ldconfig

#create account.log
cat > account.log << END
##########################################################################
# 
# thank you for using aliyun virtual machine
# 
##########################################################################

FTP:
account:www
password:ftp_password

MySQL:
account:root
password:mysql_password
END