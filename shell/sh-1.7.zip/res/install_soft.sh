#!/bin/bash

#phpwind
mkdir -p  /alidata/www/phpwind
chown -R www:www /alidata/www/phpwind/

mkdir -p  /alidata/code/bbs
mkdir -p  /alidata/code/cache
mkdir -p  /alidata/code/class
mkdir -p  /alidata/code/click/var
mkdir -p  /alidata/code/config
mkdir -p  /alidata/code/data
mkdir -p  /alidata/code/dev/var
mkdir -p  /alidata/code/dinner/var
mkdir -p  /alidata/code/distribution/var
mkdir -p  /alidata/code/FCacheSys
mkdir -p  /alidata/code/gamesite/var
mkdir -p  /alidata/code/h5Game/var
mkdir -p  /alidata/code/h5Website/var
mkdir -p  /alidata/code/image
mkdir -p  /alidata/code/kxwan/var
mkdir -p  /alidata/code/kxwannew/var
mkdir -p  /alidata/code/lib
mkdir -p  /alidata/code/log
mkdir -p  /alidata/code/mail/var
mkdir -p  /alidata/code/messageCenter/var
mkdir -p  /alidata/code/okwan/var
mkdir -p  /alidata/code/operating/var
mkdir -p  /alidata/code/operating_cpa/var
mkdir -p  /alidata/code/passport/var
mkdir -p  /alidata/code/phonesite/var
mkdir -p  /alidata/code/plist/var
mkdir -p  /alidata/code/promote/var
mkdir -p  /alidata/code/promote39/var
mkdir -p  /alidata/code/promoteDis/var
mkdir -p  /alidata/code/promoteDis3/var
mkdir -p  /alidata/code/promotenew/var
mkdir -p  /alidata/code/public
mkdir -p  /alidata/code/traffic/var
mkdir -p  /alidata/code/web/var
mkdir -p  /alidata/code/webp/var
mkdir -p  /alidata/code/webphone/var
mkdir -p  /alidata/code/webphonenew/var
mkdir -p  /alidata/code/weixin/var

groupmod -g 1010 www && usermod -u 1010 www

chown -R www:www /alidata/code
chmod 777 /alidata/code/data /alidata/code/click/var /alidata/code/dev/var /alidata/code/dinner/var /alidata/code/distribution/var /alidata/code/gamesite/var \
/alidata/code/h5Game/var /alidata/code/h5Website/var /alidata/code/kxwan/var /alidata/code/kxwannew/var /alidata/code/mail/var \
/alidata/code/messageCenter/var /alidata/code/okwan/var /alidata/code/operating/var /alidata/code/operating_cpa/var /alidata/code/passport/var \
/alidata/code/promote/var /alidata/code/promote39/var  /alidata/code/promoteDis/var /alidata/code/promoteDis3/var /alidata/code/promotenew/var \
/alidata/code/traffic/var /alidata/code/web/var /alidata/code/webp/var /alidata/code/webphone/var /alidata/code/webphonenew/var /alidata/code/weixin/var

#mkdir -p /usr/share/fonts/bitstream-vera/ && cp /alidata/code/lib/*.ttf /usr/share/fonts/bitstream-vera/ && cd /usr/share/fonts/ &&  yum install mkfontscale -y && yum install fontconfig -y && mkfontscale && mkfontdir && fc-cache


mkdir /alidata/server/rsync/client /alidata/server/rsync/server -p
cp ./res/rsyncd.conf /alidata/server/rsync/client/rsyncd.conf
cp ./res/rsyncd.rsync.pas /alidata/server/rsync/client/rsyncd.rsync.pas
chmod 600 /alidata/server/rsync/client/rsyncd.rsync.pas

echo "rsync --daemon --config=/alidata/server/rsync/cleint/rsyncd.conf"  >> /etc/rc.local

tmprsync=1
read -p "Please rsync server ip : " tmprsync
sed -i 's/^hosts allow=172.17.0.13/hosts allow='${tmprsync}'/' /alidata/server/rsync/client/rsyncd.conf


cp ./res/sersync2 /alidata/server/rsync/server/sersync2
cp ./res/confxml.xml /alidata/server/rsync/server/confxml.xml
cp ./res/serrsync.pas /alidata/server/rsync/server/serrsync.pas
chmod 600 /alidata/server/rsync/server/serrsync.pas
chmod +x /alidata/server/rsync/server/sersync2

##echo "/alidata/server/rsync/server/sersync2 -d -r -n 10 -o /alidata/server/rsync/server/confxml.xml"  >> /etc/rc.local

 
